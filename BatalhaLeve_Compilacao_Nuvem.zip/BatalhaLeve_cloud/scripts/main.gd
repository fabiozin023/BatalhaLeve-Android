extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const TargetScript = preload("res://scripts/target.gd")
const PORT := 8910
const MAX_PLAYERS := 2

var hud_label: Label
var network_label: Label
var ip_input: LineEdit
var targets_left := 0
var connected_once := false
var shot_cooldowns: Dictionary = {}
var eliminations: Dictionary = {}

func _ready() -> void:
	make_world()
	make_targets()
	make_hud()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	set_network_status("Offline — crie uma sala ou entre pelo IP do anfitrião.")

func make_world() -> void:
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.22, 0.48, 0.78)
	sky_mat.sky_horizon_color = Color(0.72, 0.84, 0.94)
	sky_mat.ground_bottom_color = Color(0.16, 0.2, 0.12)
	sky_mat.ground_horizon_color = Color(0.48, 0.58, 0.38)
	sky.sky_material = sky_mat
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.environment = environment
	add_child(env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -25, 0)
	sun.light_energy = 1.3
	add_child(sun)

	var ground := StaticBody3D.new()
	ground.name = "Ground"
	var box := BoxShape3D.new()
	box.size = Vector3(70, 1, 70)
	var collision := CollisionShape3D.new()
	collision.shape = box
	collision.position.y = -0.5
	ground.add_child(collision)
	var ground_mesh := MeshInstance3D.new()
	var plane := BoxMesh.new()
	plane.size = Vector3(70, 1, 70)
	ground_mesh.mesh = plane
	ground_mesh.position.y = -0.5
	var grass := StandardMaterial3D.new()
	grass.albedo_color = Color(0.25, 0.48, 0.22)
	grass.roughness = 1.0
	ground_mesh.material_override = grass
	ground.add_child(ground_mesh)
	add_child(ground)

	for i in range(12):
		var obstacle := StaticBody3D.new()
		var shape := BoxShape3D.new()
		shape.size = Vector3(2.5, 1.8, 2.5)
		var col := CollisionShape3D.new()
		col.shape = shape
		col.position.y = 0.9
		obstacle.add_child(col)
		var block := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = shape.size
		block.mesh = bm
		block.position.y = 0.9
		var material := StandardMaterial3D.new()
		material.albedo_color = [Color(0.62,0.48,0.31), Color(0.38,0.43,0.48), Color(0.55,0.58,0.35)][i % 3]
		block.material_override = material
		obstacle.add_child(block)
		obstacle.position = Vector3(float((i % 4) * 8 - 12), 0, float((i / 4) * 8 - 8))
		add_child(obstacle)

func make_targets() -> void:
	var positions := [Vector3(-12, 1, -8), Vector3(-5, 1, -14), Vector3(5, 1, -10), Vector3(13, 1, -2), Vector3(15, 1, 12), Vector3(-14, 1, 10)]
	for i in range(positions.size()):
		var target := StaticBody3D.new()
		target.name = "Target_%d" % (i + 1)
		target.set_script(TargetScript)
		target.position = positions[i]
		target.target_destroyed.connect(_on_target_destroyed)
		add_child(target)
	targets_left = positions.size()

func make_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var panel := PanelContainer.new()
	panel.position = Vector2(16, 16)
	panel.custom_minimum_size = Vector2(370, 170)
	layer.add_child(panel)
	var vbox := VBoxContainer.new()
	panel.add_child(vbox)
	hud_label = Label.new()
	hud_label.text = "BATALHA LEVE  |  Alvos: %d" % targets_left
	hud_label.add_theme_font_size_override("font_size", 20)
	vbox.add_child(hud_label)
	var help := Label.new()
	help.text = "WASD mover • Espaço pular • Shift correr\nClique/ATIRAR • V trocar câmera • Esc soltar mouse\nOnline: tiros, vida e eliminações sincronizados (teste)"
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(help)
	var separator := HSeparator.new()
	vbox.add_child(separator)
	var title := Label.new()
	title.text = "MULTIPLAYER DE TESTE (2 JOGADORES)"
	title.add_theme_font_size_override("font_size", 14)
	vbox.add_child(title)
	var row := HBoxContainer.new()
	vbox.add_child(row)
	var host_button := Button.new()
	host_button.text = "Criar sala"
	host_button.pressed.connect(start_host)
	row.add_child(host_button)
	ip_input = LineEdit.new()
	ip_input.placeholder_text = "IP do anfitrião"
	ip_input.text = "127.0.0.1"
	ip_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(ip_input)
	var join_button := Button.new()
	join_button.text = "Entrar"
	join_button.pressed.connect(start_client)
	row.add_child(join_button)
	network_label = Label.new()
	network_label.text = "Offline"
	network_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(network_label)

	# Botões de toque: servem para testes no Android.
	var mobile_box := HBoxContainer.new()
	mobile_box.anchor_left = 0.0
	mobile_box.anchor_top = 1.0
	mobile_box.anchor_right = 1.0
	mobile_box.anchor_bottom = 1.0
	mobile_box.offset_left = 14
	mobile_box.offset_top = -84
	mobile_box.offset_right = -14
	mobile_box.offset_bottom = -12
	mobile_box.add_theme_constant_override("separation", 8)
	layer.add_child(mobile_box)
	for item in [["◀", "move_left"], ["▲", "move_forward"], ["▼", "move_back"], ["▶", "move_right"], ["PULAR", "jump"], ["ATIRAR", "shoot"]]:
		var button := Button.new()
		button.text = item[0]
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.focus_mode = Control.FOCUS_NONE
		button.button_down.connect(_press_action.bind(item[1]))
		button.button_up.connect(_release_action.bind(item[1]))
		mobile_box.add_child(button)

func start_host() -> void:
	if not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
		set_network_status("Você já está conectado. Feche a conexão antes de iniciar outra.")
		return
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_server(PORT, MAX_PLAYERS - 1)
	if error != OK:
		set_network_status("Não foi possível criar a sala. Código: %s" % error)
		return
	multiplayer.multiplayer_peer = peer
	spawn_player.rpc(1, Vector3(0, 0.1, 12))
	set_network_status("Sala criada! Porta UDP %d. Compartilhe seu IP com o outro jogador." % PORT)

func start_client() -> void:
	if not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
		set_network_status("Você já está conectado. Reinicie o jogo para trocar de sala.")
		return
	var address := ip_input.text.strip_edges()
	if address.is_empty():
		address = "127.0.0.1"
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_client(address, PORT)
	if error != OK:
		set_network_status("Não foi possível conectar. Verifique o IP e tente novamente.")
		return
	multiplayer.multiplayer_peer = peer
	set_network_status("Conectando a %s:%d ..." % [address, PORT])

func _on_peer_connected(peer_id: int) -> void:
	if not multiplayer.is_server():
		return
	var spawn_position := Vector3(0, 0.1, -12) if peer_id != 1 else Vector3(0, 0.1, 12)
	spawn_player.rpc(peer_id, spawn_position)
	# Envia os jogadores que já existiam para o novo participante.
	for child in get_children():
		if child is CharacterBody3D and String(child.name).begins_with("Player_"):
			var existing_id := int(String(child.name).trim_prefix("Player_"))
			rpc_id(peer_id, "spawn_player", existing_id, child.global_position)
	set_network_status("Jogador %d conectado. Jogadores: %d/2" % [peer_id, multiplayer.get_peers().size() + 1])

func _on_peer_disconnected(peer_id: int) -> void:
	remove_player.rpc(peer_id)
	set_network_status("Jogador %d saiu da sala." % peer_id)

func _on_connected_to_server() -> void:
	set_network_status("Conectado! Esperando sincronização dos jogadores...")

func _on_connection_failed() -> void:
	set_network_status("Falha na conexão. Confira o IP, a rede e se o anfitrião abriu a sala.")
	multiplayer.multiplayer_peer = null

func _on_server_disconnected() -> void:
	set_network_status("A conexão com o anfitrião foi encerrada.")
	multiplayer.multiplayer_peer = null

@rpc("authority", "call_local", "reliable")
func spawn_player(peer_id: int, spawn_position: Vector3) -> void:
	var node_name := "Player_%d" % peer_id
	if has_node(node_name):
		return
	var new_player := CharacterBody3D.new()
	new_player.name = node_name
	new_player.set_script(PlayerScript)
	new_player.set_multiplayer_authority(peer_id, true)
	new_player.position = spawn_position
	add_child(new_player)
	if peer_id == multiplayer.get_unique_id():
		set_network_status("Você está na sala. Seu ID: %d" % peer_id)
	_update_local_combat_status()

@rpc("authority", "call_local", "reliable")
func remove_player(peer_id: int) -> void:
	var node := get_node_or_null("Player_%d" % peer_id)
	if node:
		node.queue_free()

func send_player_state(peer_id: int, pos: Vector3, yaw: float, pitch: float) -> void:
	if multiplayer.multiplayer_peer is OfflineMultiplayerPeer:
		return
	if multiplayer.is_server():
		broadcast_player_state.rpc(peer_id, pos, yaw, pitch)
	else:
		request_player_state.rpc_id(1, peer_id, pos, yaw, pitch)

@rpc("any_peer", "call_remote", "unreliable")
func request_player_state(peer_id: int, pos: Vector3, yaw: float, pitch: float) -> void:
	if not multiplayer.is_server():
		return
	# Só aceita que cada cliente atualize o próprio personagem.
	if multiplayer.get_remote_sender_id() != peer_id:
		return
	broadcast_player_state.rpc(peer_id, pos, yaw, pitch)

@rpc("authority", "call_local", "unreliable")
func broadcast_player_state(peer_id: int, pos: Vector3, yaw: float, pitch: float) -> void:
	var remote_player := get_node_or_null("Player_%d" % peer_id)
	if remote_player and peer_id != multiplayer.get_unique_id():
		remote_player.apply_network_state(pos, yaw, pitch)

# O cliente envia apenas a direcao da mira. O anfitriao faz o raycast e decide o acerto.
func submit_shot(shooter_id: int, aim_direction: Vector3) -> void:
	if multiplayer.multiplayer_peer is OfflineMultiplayerPeer:
		_process_server_shot(shooter_id, aim_direction)
	elif multiplayer.is_server():
		_process_server_shot(shooter_id, aim_direction)
	else:
		request_shot.rpc_id(1, shooter_id, aim_direction.normalized())

@rpc("any_peer", "call_remote", "reliable")
func request_shot(shooter_id: int, aim_direction: Vector3) -> void:
	if not multiplayer.is_server():
		return
	# Impede um cliente de atirar em nome do outro jogador.
	if multiplayer.get_remote_sender_id() != shooter_id:
		return
	_process_server_shot(shooter_id, aim_direction)

func _process_server_shot(shooter_id: int, aim_direction: Vector3) -> void:
	var shooter := get_node_or_null("Player_%d" % shooter_id)
	if shooter == null or shooter.is_eliminated:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - float(shot_cooldowns.get(shooter_id, -100.0)) < 0.22:
		return
	shot_cooldowns[shooter_id] = now
	if aim_direction.length_squared() < 0.5:
		return
	var origin: Vector3 = shooter.global_position + Vector3.UP * 1.45
	var direction: Vector3 = aim_direction.normalized()
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 70.0)
	query.exclude = [shooter.get_rid()]
	var result := get_world_3d().direct_space_state.intersect_ray(query)
	if result.is_empty():
		return
	var hit = result.get("collider")
	if hit == null:
		return
	if hit is CharacterBody3D and String(hit.name).begins_with("Player_"):
		var victim_id := int(String(hit.name).trim_prefix("Player_"))
		if victim_id == shooter_id or hit.is_eliminated:
			return
		hit.apply_server_damage(34, shooter_id)
	elif hit.has_method("apply_authoritative_hit"):
		hit.apply_authoritative_hit()
		if not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
			sync_target_hit.rpc(String(hit.name), hit.hits_left)

@rpc("authority", "call_remote", "reliable")
func broadcast_combat_status(victim_id: int, health_value: int, eliminated_value: bool, attacker_id: int, attacker_eliminations: int) -> void:
	var victim := get_node_or_null("Player_%d" % victim_id)
	if victim:
		victim.set_network_health(health_value, eliminated_value)
	var attacker := get_node_or_null("Player_%d" % attacker_id)
	if attacker:
		attacker.eliminations = attacker_eliminations
	eliminations[attacker_id] = attacker_eliminations
	_update_local_combat_status()

@rpc("authority", "call_remote", "reliable")
func sync_target_hit(target_name: String, hits_left_value: int) -> void:
	var target := get_node_or_null(target_name)
	if target and target.has_method("set_hits_from_server"):
		target.set_hits_from_server(hits_left_value)

func server_broadcast_health(victim_id: int, health_value: int, eliminated_value: bool, attacker_id: int, attacker_eliminations: int) -> void:
	if multiplayer.multiplayer_peer is OfflineMultiplayerPeer:
		_update_local_combat_status()
	else:
		broadcast_combat_status.rpc(victim_id, health_value, eliminated_value, attacker_id, attacker_eliminations)
	_update_local_combat_status()

func _update_local_combat_status() -> void:
	if not is_instance_valid(hud_label):
		return
	var local_id := multiplayer.get_unique_id()
	var local_player := get_node_or_null("Player_%d" % local_id)
	var health_text := "HP: --"
	if local_player:
		health_text = "HP: %d%s" % [local_player.health, " (ELIMINADO)" if local_player.is_eliminated else ""]
	var score := int(eliminations.get(local_id, 0))
	hud_label.text = "BATALHA LEVE  |  %s  |  Eliminações: %d  |  Alvos: %d" % [health_text, score, targets_left]

func _press_action(action_name: String) -> void:
	Input.action_press(action_name)

func _release_action(action_name: String) -> void:
	Input.action_release(action_name)

func set_network_status(message: String) -> void:
	if is_instance_valid(network_label):
		network_label.text = message

func _on_target_destroyed() -> void:
	targets_left -= 1
	if is_instance_valid(hud_label):
		hud_label.text = "BATALHA LEVE  |  Alvos restantes: %d" % targets_left
		if targets_left <= 0:
			hud_label.text = "PARABÉNS! Você acertou todos os alvos!"
