extends CharacterBody3D

@export var walk_speed: float = 5.0
@export var run_speed: float = 8.0
@export var jump_velocity: float = 7.0
@export var mouse_sensitivity: float = 0.0025

var gravity: float = 20.0
var camera_pivot: Node3D
var camera: Camera3D
var body_mesh: MeshInstance3D
var is_first_person := false
var shoot_cooldown := 0.0
var remote_position: Vector3
var remote_yaw := 0.0
var remote_pitch := 0.0
var sync_timer := 0.0
var health := 100
var is_eliminated := false
var eliminations := 0
var status_label: Label3D

func _ready() -> void:
	remote_position = global_position
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if is_multiplayer_authority() and not OS.has_feature("mobile") else Input.MOUSE_MODE_VISIBLE
	build_player()

func build_player() -> void:
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.42
	capsule.height = 1.8
	var collision := CollisionShape3D.new()
	collision.shape = capsule
	collision.position.y = 0.9
	add_child(collision)

	body_mesh = MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = 0.42
	mesh.height = 1.8
	body_mesh.mesh = mesh
	body_mesh.position.y = 0.9
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.12, 0.55, 0.95) if get_multiplayer_authority() == 1 else Color(0.95, 0.36, 0.16)
	body_mesh.material_override = mat
	add_child(body_mesh)
	status_label = Label3D.new()
	status_label.position = Vector3(0, 2.25, 0)
	status_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	status_label.font_size = 32
	status_label.outline_size = 5
	add_child(status_label)
	_update_status_label()

	camera_pivot = Node3D.new()
	camera_pivot.position.y = 1.55
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0.0, 1.0, 5.0)
	camera.rotation_degrees.x = -10.0
	camera.current = is_multiplayer_authority()
	camera_pivot.add_child(camera)
	if not is_multiplayer_authority():
		body_mesh.visible = true

func _unhandled_input(event: InputEvent) -> void:
	if not is_multiplayer_authority():
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera_pivot.rotate_x(-event.relative.y * mouse_sensitivity)
		camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, deg_to_rad(-55), deg_to_rad(35))
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT and not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if event is InputEventKey and event.pressed and event.keycode == KEY_V:
		toggle_camera()

func _process(delta: float) -> void:
	if not is_multiplayer_authority():
		global_position = global_position.lerp(remote_position, minf(delta * 12.0, 1.0))
		rotation.y = lerp_angle(rotation.y, remote_yaw, minf(delta * 12.0, 1.0))

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority() or is_eliminated:
		return
	shoot_cooldown = maxf(0.0, shoot_cooldown - delta)
	if not is_on_floor():
		velocity.y -= gravity * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	var speed := run_speed if Input.is_action_pressed("run") else walk_speed
	if direction:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)
	move_and_slide()

	if Input.is_action_just_pressed("shoot"):
		shoot()

	sync_timer -= delta
	if sync_timer <= 0.0:
		sync_timer = 0.05
		var root := get_parent()
		if root.has_method("send_player_state"):
			root.send_player_state(get_multiplayer_authority(), global_position, rotation.y, camera_pivot.rotation.x)

func shoot() -> void:
	if shoot_cooldown > 0.0 or is_eliminated:
		return
	shoot_cooldown = 0.22
	var root := get_parent()
	if root.has_method("submit_shot"):
		root.submit_shot(get_multiplayer_authority(), -camera.global_transform.basis.z)

func apply_server_damage(amount: int, attacker_id: int) -> void:
	# Executado somente no anfitriao/servidor.
	if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
		return
	if is_eliminated:
		return
	health = maxi(0, health - amount)
	if health <= 0:
		is_eliminated = true
		velocity = Vector3.ZERO
		set_physics_process(false)
		body_mesh.visible = false
		if is_instance_valid(camera):
			camera.current = false
		_update_status_label()
	_update_status_label()
	var root := get_parent()
	if root.has_method("server_broadcast_health"):
		var total_eliminations := int(root.eliminations.get(attacker_id, 0))
		if is_eliminated:
			total_eliminations += 1
			root.eliminations[attacker_id] = total_eliminations
		root.server_broadcast_health(get_multiplayer_authority(), health, is_eliminated, attacker_id, total_eliminations)

func set_network_health(new_health: int, eliminated: bool) -> void:
	health = new_health
	is_eliminated = eliminated
	if is_eliminated:
		velocity = Vector3.ZERO
		set_physics_process(false)
		body_mesh.visible = false
		if is_instance_valid(camera):
			camera.current = false
	_update_status_label()

func _update_status_label() -> void:
	if not is_instance_valid(status_label):
		return
	status_label.text = "P%d | HP %d%s" % [get_multiplayer_authority(), health, " | ELIMINADO" if is_eliminated else ""]
	status_label.modulate = Color(1.0, 0.25, 0.2) if is_eliminated else Color(1.0, 1.0, 1.0)

func apply_network_state(pos: Vector3, yaw: float, pitch: float) -> void:
	remote_position = pos
	remote_yaw = yaw
	remote_pitch = pitch

func toggle_camera() -> void:
	is_first_person = not is_first_person
	if is_first_person:
		camera.position = Vector3(0, 0.1, 0.0)
		camera.rotation = Vector3.ZERO
		body_mesh.visible = false
	else:
		camera.position = Vector3(0, 1.0, 5.0)
		camera.rotation_degrees = Vector3(-10, 0, 0)
		body_mesh.visible = true
