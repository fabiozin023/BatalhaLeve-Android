extends StaticBody3D

signal target_destroyed
var hits_left := 3
var mesh_node: MeshInstance3D

func _ready() -> void:
	var shape := SphereShape3D.new()
	shape.radius = 0.8
	var collision := CollisionShape3D.new()
	collision.shape = shape
	add_child(collision)
	mesh_node = MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.8
	mesh.height = 1.6
	mesh_node.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.95, 0.25, 0.12)
	mat.roughness = 0.8
	mesh_node.material_override = mat
	add_child(mesh_node)

# O anfitriao chama isto depois de confirmar o acerto no raycast.
func apply_authoritative_hit() -> void:
	hits_left = maxi(0, hits_left - 1)
	_apply_visual_state()

func set_hits_from_server(new_hits: int) -> void:
	hits_left = new_hits
	_apply_visual_state()

func _apply_visual_state() -> void:
	if hits_left <= 0:
		target_destroyed.emit()
		queue_free()
	else:
		mesh_node.scale = Vector3.ONE * (0.82 ** (3 - hits_left))
